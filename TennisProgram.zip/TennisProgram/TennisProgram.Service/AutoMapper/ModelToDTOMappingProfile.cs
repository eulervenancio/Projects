﻿using AutoMapper;
using TennisProgram.Domain.Entities;
using TennisProgram.Domain.Models;
using TennisProgram.Domain.Models.Response;

namespace TennisProgram.Service.AutoMapper
{
    public class ModelToDTOMappingProfile : Profile
    {
        public ModelToDTOMappingProfile()
        {
            CreateMap<JogoTenisModel, JogoTenis>();
            CreateMap<JogadorModel, Jogador>();

            #region request

            CreateMap<AtualizarJogadorModelRequest, Jogador>();
            CreateMap<CriarJogadorModelResquest, Jogador>();
            CreateMap<CriarJogoTenisModeRequest, JogoTenis>();
            CreateMap<AtualizarJogoTenisModeRequest, JogoTenis>();

            #endregion

            #region responde

            CreateMap<NovoJogadorModelResponse, Jogador>();
            CreateMap<JogoTenisRegraModelResponse, JogoTenis>();
            CreateMap<InciarJogoModelResponse, JogoTenis>();

            #endregion

        }
    }
}
