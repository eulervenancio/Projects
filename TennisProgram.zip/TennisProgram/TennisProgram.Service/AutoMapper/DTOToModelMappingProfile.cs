﻿using AutoMapper;
using System.Collections.Generic;
using TennisProgram.Domain.Entities;
using TennisProgram.Domain.Models;
using TennisProgram.Domain.Models.Response;

namespace TennisProgram.Service.AutoMapper
{
    public class DTOToModelMappingProfile : Profile
    {
        public DTOToModelMappingProfile()
        {
            CreateMap<JogoTenis, JogoTenisModel>();
            CreateMap<Jogador, JogadorModel>();            

            CreateMap<JogoTenis, JogoTenisRegraModelResponse>();
            CreateMap<Jogador, NovoJogadorModelResponse>();
            CreateMap<Jogador, InciarJogoModelResponse>();
            CreateMap<IEnumerable<JogoTenisModel>, IEnumerable<JogoTenisModel>>();
        }
    }
}
