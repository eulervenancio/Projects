﻿using System;
using TennisProgram.Domain.Models;
using TennisProgram.Domain.Interfaces.Services;
using TennisProgram.Domain.Interfaces.Resositories;
using System.Collections.Generic;
using TennisProgram.Domain.Interfaces.UnitOfWork;
using AutoMapper;
using TennisProgram.Domain.Entities;
using System.Threading.Tasks;

namespace TennisProgram.Service.Service
{
    public class JogoTenisService : ServiceBase, IJogoTenisService
    {
        private readonly IMapper _mapper;
        public JogoTenisService(IMapper mapper, IUnitOfWork unitOfWork) : base(unitOfWork)
        {
            _mapper = mapper;
        }

        public async Task<JogoTenisModel> Atualizar(Guid id, AtualizarJogoTenisModeRequest jogoModel)
        {
            if (!VerificarSeExisteRegistroNaBasePorID(id))
                return null;

            var entidade = new JogoTenis(id, jogoModel.DescricaoJogo, jogoModel.Empatado);

            _unitOfWork.jogoTenisRepository.Update(entidade);

            var retorno = RecuperarPorId(id);

            return retorno;
        }
      
        public async Task<JogoTenisModel> Inserir(string jogoTenisDescricao)
        {
            var jogoTenis = new JogoTenis(jogoTenisDescricao);

            _unitOfWork.jogoTenisRepository.Add(jogoTenis);

            return MapearEntidadeParaModelo(jogoTenis);
        }

        public JogoTenisModel RecuperarPorId(Guid id)
        {
            return _mapper.Map<JogoTenisModel>(_unitOfWork.jogoTenisRepository.GetById(id));
        }

        public void Excluir(Guid id)
        {
            if (!VerificarSeExisteRegistroNaBasePorID(id))
                throw new Exception("Registro não existe");

            _unitOfWork.jogoTenisRepository.Remove(id);
        }

        #region Métodos Privados
        internal bool VerificarSeExisteRegistroNaBasePorID(Guid id)
        {
            var jogoTenisBD = RecuperarPorId(id);
            return !(jogoTenisBD == null || string.IsNullOrEmpty(jogoTenisBD.Descricao));
        }
        internal bool VerificarSeExisteRegistroNaBase(JogoTenisModel jogoTenisModel)
        {
            if (jogoTenisModel == null || string.IsNullOrEmpty(jogoTenisModel.Descricao))
                return false;

            var jogoTenisBD = RecuperarPorId(jogoTenisModel.Id);
            return !(jogoTenisBD == null || string.IsNullOrEmpty(jogoTenisBD.Descricao));
        }

        private JogoTenisModel MapearEntidadeParaModelo(JogoTenis jogoTenis)
        {
            if (jogoTenis == null || string.IsNullOrEmpty(jogoTenis.Descricao))
                return null;

            return _mapper.Map<JogoTenisModel>(jogoTenis);
        }

        public IEnumerable<JogoTenisModel> RecuperarTodos()
        {
            var retorno =  _unitOfWork.jogoTenisRepository.GetAll();
           return _mapper.Map<IEnumerable<JogoTenisModel>>(retorno); 
        }

        #endregion

    }
}
