﻿using AutoMapper;
using System;
using System.Threading.Tasks;
using TennisProgram.Domain.Interfaces.Services;
using TennisProgram.Domain.Interfaces.UnitOfWork;
using TennisProgram.Domain.Models;
using TennisProgram.Domain.Models.Response;

namespace TennisProgram.Service.Service
{
    public class JogoTenisRegraService : ServiceBase, IJogoTenisRegraService
    {
        private readonly IMapper _mapper;
        private readonly JogadorService _jogadorService;
        private readonly JogoTenisService _jogoTenisService;

        public JogoTenisRegraService(IMapper mapper, IUnitOfWork unitOfWork) : base(unitOfWork)
        {
            _mapper = mapper;
            _jogoTenisService = new JogoTenisService(mapper, unitOfWork);
            _jogadorService = new JogadorService(mapper, unitOfWork);
        }

        public async Task<JogoTenisRegraModelResponse> NovoJogo(string jogoTenisDescricao)
        {
            JogoTenisRegraModelResponse retorno = new JogoTenisRegraModelResponse();

            var novoJogo = await  _jogoTenisService.Inserir(jogoTenisDescricao);

            if (_jogoTenisService.VerificarSeExisteRegistroNaBase(novoJogo))
            { 
                retorno.JogoTenisModel = novoJogo;
            }
            else
            {
                retorno.Sucesso = false;
                retorno.MensagemRetorno = "O Jogo NÃO foi criardo!";
            }
            return retorno;
        }

        public async Task<NovoJogadorModelResponse> CriarNovoJogador(Guid idJogo, string nomeJogador)
        {
            NovoJogadorModelResponse retorno = new NovoJogadorModelResponse();

            var jogadorModel = await _jogadorService.Inserir(new CriarJogadorModelResquest
            {
                IdJogo = idJogo,
                Nome = nomeJogador,
                Pontuacao = 0,
                EmVantagem = false
            });

            if (_jogadorService.VerificarSeExisteRegistroNaBase(jogadorModel))
            {
                retorno.JogadorModel = jogadorModel;                
            }
            else
            {
                retorno.Sucesso = false;
                retorno.MensagemRetorno = "O Jogo NÃO foi criardo!";
            }

            return retorno;
        }

    }
}
