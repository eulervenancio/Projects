﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TennisProgram.Domain.Entities;
using TennisProgram.Domain.Interfaces.Resositories;
using TennisProgram.Domain.Interfaces.Services;
using TennisProgram.Domain.Interfaces.UnitOfWork;
using TennisProgram.Domain.Models;

namespace TennisProgram.Service.Service
{
    public class JogadorService : ServiceBase, IJogadorService
    {
        private readonly IMapper _mapper;
        public JogadorService(IMapper mapper, IUnitOfWork unitOfWork) : base(unitOfWork)
        {
            _mapper = mapper;
        }

        public async Task<JogadorModel> Atualizar(Guid id, AtualizarJogadorModelRequest jogadorModel)
        {
            if (!VerificarSeExisteRegistroNaBasePorId(id))
                return null;

            var jogador = new Jogador(id,jogadorModel.IdJogo, jogadorModel.Nome, jogadorModel.Pontuacao, jogadorModel.EmVantagem);

             _unitOfWork.jogadorRepository.Update(jogador);

            var retorno = RecuperarPorId(id);

            return retorno;
        }

        public void Excluir(Guid id)
        {
            throw new NotImplementedException();
        }

        public async Task<JogadorModel> Inserir(CriarJogadorModelResquest jogadorModel)
        {   
            var jogador = new Jogador(jogadorModel.IdJogo, jogadorModel.Nome, jogadorModel.Pontuacao, jogadorModel.EmVantagem);
            
            _unitOfWork.jogadorRepository.Add(jogador);

            var retorno = RecuperarPorId(jogador.Id);

            return retorno;
        }

        public JogadorModel RecuperarPorId(Guid id)
        {
            return _mapper.Map<JogadorModel>(_unitOfWork.jogadorRepository.GetById(id));
        }

        public IEnumerable<JogadorModel> RecuperarTodosPorIdJogo(Guid id)
        {
            throw new NotImplementedException();
        }

        internal bool VerificarSeExisteRegistroNaBasePorId(Guid id)
        {
            var jogador = RecuperarPorId(id);
            return !(jogador == null || string.IsNullOrEmpty(jogador.Nome));
        }

        internal bool VerificarSeExisteRegistroNaBase(JogadorModel jogadorModel)
        {
            if (jogadorModel == null || string.IsNullOrEmpty(jogadorModel.Nome))
                return false;

            var jogadorBD = RecuperarPorId(jogadorModel.Id);
            return !(jogadorBD == null || string.IsNullOrEmpty(jogadorBD.Nome));
        }
    }
}
