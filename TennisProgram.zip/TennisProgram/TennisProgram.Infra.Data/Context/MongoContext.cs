﻿using MongoDB.Driver;
using TennisProgram.Infra.Data.Interfaces;

namespace TennisProgram.Infra.Data.Context
{
    public class MongoContext : IMongoContext
    {
        private IMongoDatabase _database { get; set; }
        public IClientSessionHandle session { get; set; }
        private MongoClient _mongoClient { get; set; }
       
        public MongoContext()
        {   
            _mongoClient = new MongoClient(Constantes.VariaveisAmbiente.Connection);
            _database = _mongoClient.GetDatabase(Constantes.VariaveisAmbiente.DatabaseName);
        }

        public IMongoCollection<T> GetCollection<T>(string name)
        {
            if (string.IsNullOrEmpty(name))
                return null;

            return _database.GetCollection<T>(name);
        }

        public void Dispose()
        {   
         
        }
    }
}
