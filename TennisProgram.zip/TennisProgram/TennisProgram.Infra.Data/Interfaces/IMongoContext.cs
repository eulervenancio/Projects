﻿using MongoDB.Driver;
using System;
using System.Threading.Tasks;

namespace TennisProgram.Infra.Data.Interfaces
{
    public interface IMongoContext : IDisposable
    {
        IMongoCollection<T> GetCollection<T>(string name);
    }
}
