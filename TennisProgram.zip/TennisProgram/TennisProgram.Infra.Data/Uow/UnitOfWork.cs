﻿using System.Threading.Tasks;
using TennisProgram.Domain.Interfaces.Resositories;
using TennisProgram.Domain.Interfaces.UnitOfWork;
using TennisProgram.Infra.Data.Interfaces;
using TennisProgram.Infra.Data.Repositories;

namespace TennisProgram.Infra.Data.Uow
{
    public sealed class UnitOfWork : IUnitOfWork
    {
        private readonly IMongoContext _context; 

        public UnitOfWork(IMongoContext context)
        {
            _context = context;
        }
        public IJogoTenisRepository jogoTenisRepository => new JogoTenisRepository(_context);
        public IJogadorRepository jogadorRepository => new JogadorRepository(_context);
        public void Dispose()
        {
            _context.Dispose();
        }
    }
}
