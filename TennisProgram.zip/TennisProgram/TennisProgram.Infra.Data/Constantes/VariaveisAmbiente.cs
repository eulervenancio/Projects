﻿
namespace TennisProgram.Infra.Data.Constantes
{
    public static class VariaveisAmbiente
    {
        public const string Connection = "mongodb://localhost:27017";
        public const string DatabaseName = "JogoDataBase";
    }
}
