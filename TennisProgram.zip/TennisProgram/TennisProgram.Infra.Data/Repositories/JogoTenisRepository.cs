﻿using TennisProgram.Domain.Entities;
using TennisProgram.Domain.Interfaces.Resositories;
using TennisProgram.Infra.Data.Interfaces;

namespace TennisProgram.Infra.Data.Repositories
{
    public class JogoTenisRepository : BaseRepository<JogoTenis>, IJogoTenisRepository
    {
        public JogoTenisRepository(IMongoContext context) : base(context)
        {
        }

    }
}
