﻿using TennisProgram.Domain.Entities;
using TennisProgram.Domain.Interfaces.Resositories;
using TennisProgram.Infra.Data.Interfaces;

namespace TennisProgram.Infra.Data.Repositories
{
    public class JogadorRepository : BaseRepository<Jogador>, IJogadorRepository
    {
        public JogadorRepository(IMongoContext context) : base(context)
        {
        }

    }
}
