﻿using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TennisProgram.Domain.Interfaces.Resositories;
using TennisProgram.Infra.Data.Interfaces;
using ServiceStack;

namespace TennisProgram.Infra.Data.Repositories
{
    public abstract class BaseRepository<TEntity> : IRepository<TEntity> where TEntity : class
    {
        protected readonly IMongoContext _mongoDBContext;
        protected IMongoCollection<TEntity> DbSet;

        protected BaseRepository(IMongoContext context)
        {
            _mongoDBContext = context;

            DbSet = _mongoDBContext.GetCollection<TEntity>(typeof(TEntity).Name);
        }

        public virtual void Add(TEntity obj)
        {
             DbSet.InsertOneAsync(obj);
        }

        public virtual TEntity GetById(Guid id)
        {
            var data = DbSet.Find(Builders<TEntity>.Filter.Eq("_id", id));
            return data.SingleOrDefault();
        }

        public virtual async Task<IEnumerable<TEntity>> GetAll()
        {
            var all = await DbSet.FindAsync(Builders<TEntity>.Filter.Empty);
            return all.ToList();
        }

        public virtual void Update(TEntity obj)
        {
            DbSet.ReplaceOneAsync(Builders<TEntity>.Filter.Eq("_id", obj.GetId()), obj);
        }

        public virtual void Remove(Guid id)
        {
            DbSet.DeleteOneAsync(Builders<TEntity>.Filter.Eq("_id", id));
        }

        public void Dispose()
        {
            _mongoDBContext?.Dispose();
        }


    }
}
