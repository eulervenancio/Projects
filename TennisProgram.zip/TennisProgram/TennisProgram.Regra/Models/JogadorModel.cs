﻿
using System;

namespace TennisProgram.Domain.Models
{
    public class JogadorModel
    {
        public Guid Id { get; set; }
        public Guid IdJogo { get; set; }
        public string Nome { get; set; }
        public int Pontuacao { get; set; }
        public bool EmVantagem { get; set; }
        public JogadorModel(Guid id, Guid idJogo,  string nome, int pontuacao,bool emVantagem)
        {
            Id = id;
            IdJogo = idJogo;
            Nome = nome;
            Pontuacao = pontuacao;
            EmVantagem = emVantagem;
        }

        public JogadorModel(Guid idJogo, string nome, int pontuacao, bool emVantagem)
        {
            Id = Guid.NewGuid();
            IdJogo = idJogo;
            Nome = nome;
            Pontuacao = pontuacao;
            EmVantagem = emVantagem;
        }
        public JogadorModel(){}

    }
}
