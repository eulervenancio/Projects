﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TennisProgram.Domain.Models.Response
{
    public class JogoTenisRegraModelResponse : ModeBaselResponse
    {
        public JogoTenisModel JogoTenisModel { get; set; }
    }
}
