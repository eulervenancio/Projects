﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TennisProgram.Domain.Models.Response
{
    public class InciarJogoModelResponse : ModeBaselResponse
    {
        public JogoTenisModel jogoTenisModel { get; set; }
    }
}
