﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TennisProgram.Domain.Models.Response
{
    public class ModeBaselResponse
    {
        public bool Sucesso { get; set; }
        public string MensagemRetorno { get; set; }

        public ModeBaselResponse()
        {
            Sucesso = true;
            MensagemRetorno = "";
        }
    }
}
