﻿

using System;

namespace TennisProgram.Domain.Models
{
    public class JogoTenisModel
    {
        public Guid Id { get; set; }
        public string Descricao { get; set; }
        public bool Empatado { get; set; }

        public JogoTenisModel(Guid id, string descricaoJogo, bool empatado)
        {
            Id = id;
            Descricao = descricaoJogo;            
            Empatado = empatado;
        }

        public JogoTenisModel()
        {
        }

    }
}
