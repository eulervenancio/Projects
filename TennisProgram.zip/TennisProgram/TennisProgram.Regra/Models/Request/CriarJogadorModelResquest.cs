﻿
using System;

namespace TennisProgram.Domain.Models
{
    public class CriarJogadorModelResquest
    {
        public Guid IdJogo { get; set; }
        public string Nome { get; set; }
        public int Pontuacao { get; set; }
        public bool EmVantagem { get; set; }
    }
}
