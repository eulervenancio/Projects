﻿using System;

namespace TennisProgram.Domain.Models.Request
{
    public class CriarNovoJogadorRegraModelResquest
    {
        public Guid IdJogo { get; set; }
        public string Nome { get; set; }
    }
}
