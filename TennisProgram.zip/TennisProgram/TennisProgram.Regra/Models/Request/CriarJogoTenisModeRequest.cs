﻿

using System;

namespace TennisProgram.Domain.Models
{
    public class CriarJogoTenisModeRequest
    {
        public CriarJogoTenisModeRequest(string descricaoJogo)
        {
            DescricaoJogo = descricaoJogo;            
            Empatado = false;
            Id = Guid.NewGuid();
        }

        public string DescricaoJogo { get; set; }
        private bool Empatado { get; set; }
        public Guid Id { get; private set; }

    }
}
