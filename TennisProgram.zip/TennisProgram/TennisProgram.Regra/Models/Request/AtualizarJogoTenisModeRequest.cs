﻿

namespace TennisProgram.Domain.Models
{
    public class AtualizarJogoTenisModeRequest
    {   
        public string DescricaoJogo { get; set; }
        public bool Empatado { get; set; }

        public AtualizarJogoTenisModeRequest(string descricaoJogo, bool empatado)
        {   
            DescricaoJogo = descricaoJogo;            
            Empatado = empatado;
        }
    }
}
