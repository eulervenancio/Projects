﻿
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TennisProgram.Domain.Models;

namespace TennisProgram.Domain.Interfaces.Services
{
    public interface IJogoTenisService
    {
        Task<JogoTenisModel> Inserir(string jogoTenisDescricao);
        Task<JogoTenisModel> Atualizar(Guid id, AtualizarJogoTenisModeRequest jogoModel);
        JogoTenisModel RecuperarPorId(Guid id);
        void Excluir(Guid id);
        IEnumerable<JogoTenisModel> RecuperarTodos();
    }
}
