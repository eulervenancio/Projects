﻿using System;
using System.Threading.Tasks;
using TennisProgram.Domain.Models.Response;

namespace TennisProgram.Domain.Interfaces.Services
{
    public interface IJogoTenisRegraService
    {
        Task<JogoTenisRegraModelResponse> NovoJogo(string jogoTenisDescricao);

        Task<NovoJogadorModelResponse> CriarNovoJogador(Guid idJogo, string nomeJogador);
    }
}
