﻿
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TennisProgram.Domain.Models;

namespace TennisProgram.Domain.Interfaces.Services
{
    public interface IJogadorService
    {
        Task<JogadorModel> Inserir(CriarJogadorModelResquest jogadorModel);
        Task<JogadorModel> Atualizar(Guid id, AtualizarJogadorModelRequest jogadorModel);
        JogadorModel RecuperarPorId(Guid id);
        void Excluir(Guid id);
        IEnumerable<JogadorModel> RecuperarTodosPorIdJogo(Guid id);
    }
}
