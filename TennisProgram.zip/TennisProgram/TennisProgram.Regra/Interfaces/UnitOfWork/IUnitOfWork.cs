﻿using System;
using TennisProgram.Domain.Interfaces.Resositories;

namespace TennisProgram.Domain.Interfaces.UnitOfWork
{
    public interface IUnitOfWork : IDisposable
    {
        IJogoTenisRepository jogoTenisRepository { get; }
        IJogadorRepository jogadorRepository { get; }
    }
}
