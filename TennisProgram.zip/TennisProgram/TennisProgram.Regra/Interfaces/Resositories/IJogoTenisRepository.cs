﻿using TennisProgram.Domain.Entities;

namespace TennisProgram.Domain.Interfaces.Resositories
{
    public interface IJogoTenisRepository : IRepository<JogoTenis>
    {
      
    }
}
