﻿using TennisProgram.Domain.Entities;

namespace TennisProgram.Domain.Interfaces.Resositories
{    
    public interface IJogadorRepository : IRepository<Jogador>
    {
    }
}
