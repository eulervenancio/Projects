﻿
using System;

namespace TennisProgram.Domain.Entities
{
    public class Jogador
    {
        public Guid Id { get; set; }
        public Guid IdJogo { get; set; }
        public string Nome { get; set; }
        public int Pontuacao { get; set; }
        public bool EmVantagem { get; set; }

        public Jogador(Guid id, Guid idJogo, string nome, int pontuacao, bool emVantagem)
        {
            Id = id;
            IdJogo = idJogo;
            Nome = nome;
            Pontuacao = pontuacao;
            EmVantagem = emVantagem;
        }

        public Jogador(Guid idJogo, string nome, int pontuacao, bool emVantagem)
        {
            Id = Guid.NewGuid();
            IdJogo = idJogo;
            Nome = nome;
            Pontuacao = pontuacao;
            EmVantagem = emVantagem;
        }
        public Jogador() { }

    }
}
