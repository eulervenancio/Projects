﻿
using System;

namespace TennisProgram.Domain.Entities
{
    public class JogoTenis
    {
        public JogoTenis(string descricao)
        {           
            Descricao = descricao;
            Id = Guid.NewGuid();
            Empatado = false;
        }

        public JogoTenis(Guid id, string descricao)
        {
            Descricao = descricao;
            Id = id;
            Empatado = false;
        }

        public JogoTenis(Guid id, string descricao, bool empatado)
        {
            Descricao = descricao;
            Id = id;
            Empatado = empatado;
        }
        public Guid Id { get; private set; }
        public string Descricao { get; private set; }
        public bool Empatado { get; private set; }
    }
}
