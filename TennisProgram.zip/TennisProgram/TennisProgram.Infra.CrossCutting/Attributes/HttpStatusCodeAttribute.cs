﻿using System;


namespace TennisProgram.Infra.CrossCutting.Attributes
{
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = true)]
    public class HttpStatusCodeAttribute : Attribute
    {
        private readonly int _statusCode;

        public HttpStatusCodeAttribute(int statusCode)
        {
            _statusCode = statusCode;
        }

        public int StatusCode { get => _statusCode; }
    }
}
