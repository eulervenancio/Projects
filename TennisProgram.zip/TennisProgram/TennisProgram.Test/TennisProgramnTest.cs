using NUnit.Framework;
using TennisProgram.Service.Service;
using TennisProgram.Domain.Interfaces.Services;
using System.Threading.Tasks;
using TennisProgram.Domain.Models.Response;
using System;
using TennisProgram.Domain.Models;
using TennisProgram.Infra.Data.Uow;
using TennisProgram.Infra.Data.Context;
using Microsoft.Extensions.DependencyInjection;
using AutoMapper;
using TennisProgram.Service.AutoMapper;

namespace TennisProgram.Test
{
    public class TennisProgramnTest
    {
        private readonly IJogoTenisRegraService _jogoTenisRegraService;
        public MongoContext mongoContext;
        public UnitOfWork _UnitOfWork;
        public JogoTenisModel _jogoTenis { get; set; }
        public JogadorModel jogador { get; set; }

        public TennisProgramnTest()
        {
            mongoContext = new MongoContext();
            _UnitOfWork = new UnitOfWork(mongoContext);

            var serviceProvider = new ServiceCollection()
                            .AddSingleton(new MapperConfiguration(configure =>
                            {
                                configure.AllowNullCollections = true;
                                configure.AddProfile(new ModelToDTOMappingProfile());
                                configure.AddProfile(new DTOToModelMappingProfile());
                            }).CreateMapper())
                            .BuildServiceProvider();

            _jogoTenisRegraService = new JogoTenisRegraService(serviceProvider.GetService<IMapper>(), _UnitOfWork);

        }



        [Test]
        public async Task InciarNovoJogo_Retorna_Sucesso()
        {
            try
            {
                var resultado = await _jogoTenisRegraService.NovoJogo("Jogo Teste #" + RetornarNummeroAleatorio());
                _jogoTenis = resultado.JogoTenisModel;
                Assert.IsTrue(resultado.Sucesso);

            }
            catch (Exception)
            {
                Assert.Fail();
            }
        }

        [Test]
        public async Task CriarNovoJogador_Retorna_Sucesso()
        {
            try
            {
                if (_jogoTenis == null)
                {
                    var resultadoJogo = await _jogoTenisRegraService.NovoJogo("Jogo Teste #" + RetornarNummeroAleatorio());
                    _jogoTenis = resultadoJogo.JogoTenisModel;
                }

                var resultado = await _jogoTenisRegraService.CriarNovoJogador(_jogoTenis.Id, "Jogador teste #" + RetornarNummeroAleatorio());
                Assert.IsTrue(resultado.Sucesso);

            }
            catch (Exception)
            {
                Assert.Fail();
            }
        }

        private string RetornarNummeroAleatorio()
        {
            return DateTime.Now.Ticks.ToString().Substring(4);
        }

    }
}