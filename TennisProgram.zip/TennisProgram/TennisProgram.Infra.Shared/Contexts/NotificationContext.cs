﻿
namespace TennisProgram.Infra.Shared.Contexts
{
    public class NotificationContext
    {
    }
}
