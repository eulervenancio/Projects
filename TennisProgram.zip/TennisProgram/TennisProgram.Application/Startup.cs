using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.IO;
using TennisProgram.Application.Filter;
using Microsoft.OpenApi.Models;
using TennisProgram.Infra.IoC;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using AutoMapper;
using TennisProgram.Service.AutoMapper;
using TennisProgram.Application.Configurations;
using Microsoft.AspNetCore.Http;

namespace TennisProgram.Application
{
    public class Startup
    {
        public Startup()
        {
            var enviroment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");

            if (string.IsNullOrEmpty(enviroment?.Trim()))
            {
                Console.WriteLine("A vari�vel de ambiente ASPNETCORE_ENVIRONMENT n�o foi definida. Aplica��o ser� encerrada.");
                Environment.Exit(1);
            }

            var configurationBuilder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile(Path.Combine(AppContext.BaseDirectory, "appsettings.json"), false)
                .AddJsonFile(Path.Combine(AppContext.BaseDirectory, $"appsettings.{enviroment}.json"), false, true);

            Configuration = configurationBuilder.Build();
        }

        public IConfiguration Configuration { get; }
        public readonly string MyPolicy = "_myPolicy";
        public readonly string environmentName = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");


        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors(options =>
            {
                options.AddPolicy(MyPolicy,
                    builder =>
                    {
                        builder.AllowAnyOrigin()
                               .AllowAnyMethod()
                               .AllowAnyHeader();
                    });
            });

            services.AddHealthChecks();

            services.AddControllers(p =>
            {
                p.Filters.Add<ApiExceptionFilterAttribute>();
                p.EnableEndpointRouting = false;
            }).SetCompatibilityVersion(CompatibilityVersion.Version_3_0)
            .AddNewtonsoftJson(options =>
        options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore);


            new InjetorDependencias(services, Configuration).ConfigurarDependencias();

            RegisterSwagger(services, Configuration);

            services.AddSingleton(new MapperConfiguration(configure =>
            {
                configure.AllowNullCollections = true;
                configure.AddProfile(new ModelToDTOMappingProfile());
                configure.AddProfile(new DTOToModelMappingProfile());
            }).CreateMapper());

            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            
            MongoDbPersistence.Configure();           
            
        }


        private void RegisterSwagger(IServiceCollection services, IConfiguration configuration)
        {
            services.AddSwaggerGen(p =>
            {
                p.SwaggerDoc("v1", new OpenApiInfo
                {
                    Version = $"v1 - {configuration["Ambiente"]}",
                    Title = "API Jogo de Tenis",
                    Description = "API Jogo de Tenis",
                    Contact = new OpenApiContact { Name = "Euler Ven�ncio", Email = "euler.marcio@gmail.com", }
                });

            });
        }

        //// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
            }

            app.UseRouting();

            app.UseCors(MyPolicy);

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapHealthChecks("/health");
            });

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.RoutePrefix = "swagger";
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "API Jogo de Tenis");
            });

            app.UseMvc();
        }
    }
}
