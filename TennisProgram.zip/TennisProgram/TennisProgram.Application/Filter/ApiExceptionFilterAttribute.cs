﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Linq;
using TennisProgram.Infra.CrossCutting.Attributes;

namespace TennisProgram.Application.Filter
{
    public class ApiExceptionFilterAttribute : ExceptionFilterAttribute
    {
        public override void OnException(ExceptionContext context)
        {
            var exception = context.Exception;

            int statusCode = ObterStatusCode(exception);

            context.Result = CriarResultadoErro(statusCode, exception);
        }

        private int ObterStatusCode(Exception exception)
        {
            var statusCodeAttribute = exception.GetType().GetCustomAttributes(typeof(HttpStatusCodeAttribute), true).FirstOrDefault();

            if (statusCodeAttribute != null)
                return (statusCodeAttribute as HttpStatusCodeAttribute).StatusCode;

            // Se a exception não possui um HttpStatusCodeAttribute definido, utiliza valores default.
            return 500;
        }

        private ObjectResult CriarResultadoErro(int statusCode, Exception exception)
        {
            if (statusCode == 500)
            {
                return new ObjectResult(new RetornoErro(exception.Message, exception.StackTrace))
                {
                    StatusCode = statusCode
                };
            }
            //Todas as outras: validacão, existente, inexistente, etc.
            return new ObjectResult(new RetornoValidacao(exception.Message)) { StatusCode = statusCode };
        }
    }

    public class RetornoValidacao
    {
        public string Message { get; set; }

        public RetornoValidacao(string message)
        {
            Message = message;
        }
    }

    public class RetornoErro : RetornoValidacao
    {
        public string StackTrace { get; set; }

        public RetornoErro(string message, string stackTrace)
            : base(message)
        {
            StackTrace = stackTrace;
        }
    }


}
