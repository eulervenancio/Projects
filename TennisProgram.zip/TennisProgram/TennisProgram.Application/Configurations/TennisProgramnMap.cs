﻿
using MongoDB.Bson.Serialization;
using TennisProgram.Domain.Entities;

namespace TennisProgram.Application.Configurations
{
    public class TennisProgramnMap
    {
        public static void Configure()
        {
            BsonClassMap.RegisterClassMap<JogoTenis>(map =>
            {
                map.AutoMap();
                map.SetIgnoreExtraElements(true);
                map.MapIdMember(x => x.Id);
                map.MapMember(x => x.Descricao).SetIsRequired(true);
            });
        }
    }
}
