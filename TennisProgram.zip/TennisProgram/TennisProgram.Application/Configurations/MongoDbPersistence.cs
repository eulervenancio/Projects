﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Conventions;

namespace TennisProgram.Application.Configurations
{
    public static class MongoDbPersistence
    {
        public static object ProductMap { get; private set; }

        public static void Configure()
        {
            TennisProgramnMap.Configure();

            BsonDefaults.GuidRepresentation = GuidRepresentation.CSharpLegacy;

            // Conventions
            var pack = new ConventionPack
                {
                    new IgnoreExtraElementsConvention(true),
                    new IgnoreIfDefaultConvention(true)
                };
            ConventionRegistry.Register("My Solution Conventions", pack, t => true);
        }
    }
}
