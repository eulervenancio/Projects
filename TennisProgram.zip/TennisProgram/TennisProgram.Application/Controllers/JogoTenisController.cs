﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TennisProgram.Domain.Interfaces.Services;
using TennisProgram.Domain.Interfaces.UnitOfWork;
using TennisProgram.Domain.Models;

namespace TennisProgram.Application.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class JogoTenisController : ControllerBase
    {
        private readonly IJogoTenisService _jogoTenisService;        
        private readonly IMapper _mapper;
        private readonly IUnitOfWork _unitOfWork;        
        public JogoTenisController(IJogoTenisService jogoTenisService,  IMapper mapper, IUnitOfWork unitOfWork)
        {
            _jogoTenisService = jogoTenisService;
            _mapper = mapper;
            _unitOfWork = unitOfWork;
        }

        [HttpPost]
        [Route("CRUD/Inserir")]
        public async Task<ActionResult<JogoTenisModel>> Inserir([FromBody] string jogoTenisDescricao)
        {
            try
            {
                var jogoTenis = await _jogoTenisService.Inserir(jogoTenisDescricao);

                return Ok(jogoTenis);
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpGet]
        [Route("CRUD/RetonarPorId")]
        public async Task<ActionResult<JogoTenisModel>> RetornarPorId([FromBody] Guid id)
        {
            try
            {
                var jogoTenis = _jogoTenisService.RecuperarPorId(id);

                return Ok(jogoTenis);
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpGet]
        [Route("CRUD/RecuperarTodos")]
        public async Task<ActionResult<IEnumerable<JogoTenisModel>>> RecuperarTodos()
        {
            try
            {
                //var jogoTenis = _jogoTenisService.RecuperarTodos();

                return Ok(null);
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpPut]
        [Route("CRUD/Alterar/{id}")]
        public async Task<ActionResult<JogoTenisModel>> Alterar(Guid id, [FromBody] AtualizarJogoTenisModeRequest jogoTenisModel)
        {
            try
            {
                var jogoTenis = await _jogoTenisService.Atualizar(id, jogoTenisModel);

                return Ok(jogoTenis);
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpDelete]
        [Route("CRUD/Excluir/{id}")]
        public async Task<ActionResult> Excluir(Guid id)
        {
            try
            {
                _jogoTenisService.Excluir(id);

                return Ok();
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }

        }


    }
}
