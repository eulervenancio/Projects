﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using TennisProgram.Domain.Interfaces.Services;
using TennisProgram.Domain.Models;
using TennisProgram.Domain.Models.Request;
using TennisProgram.Domain.Models.Response;

namespace TennisProgram.Application.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class JogoTenisRegraController : Controller
    {
        private readonly IJogoTenisRegraService _jogoTenisRegraService;             

        public JogoTenisRegraController(IJogoTenisRegraService jogoTenisRegraService)
        {
            _jogoTenisRegraService = jogoTenisRegraService;
        }

        [HttpPost]
        [Route("Regra/NovoJogo")]
        public async Task<ActionResult<JogoTenisRegraModelResponse>> NovoJogo([FromBody] string jogoTenisDescricao)
        {
            try
            {
                var jogoTenis = await _jogoTenisRegraService.NovoJogo(jogoTenisDescricao);

                return Ok(jogoTenis);
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpPost]
        [Route("Regra/CriarNovoJogador")]
        public async Task<ActionResult<NovoJogadorModelResponse>> CriarNovoJogador([FromBody] CriarNovoJogadorRegraModelResquest criarJogadorModelResquest)
        {
            try
            {
                var jogoTenis = await _jogoTenisRegraService.CriarNovoJogador(criarJogadorModelResquest.IdJogo, criarJogadorModelResquest.Nome);

                return Ok(jogoTenis);
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpPatch]
        [Route("Regra/AtualizarPontuacaoJogador")]
        public async Task<ActionResult<JogoTenisRegraModelResponse>> AtualizarPontuacaoJogador([FromBody] AtualizarJogadorModelRequest criarJogadorModelResquest)
        {
            try
            {
                return new JogoTenisRegraModelResponse { Sucesso = false, MensagemRetorno = "Não implementado!"};                

            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpGet]
        [Route("Regra/VerficarGanhadorJogo")]
        public async Task<ActionResult<JogoTenisRegraModelResponse>> VerficarGanhadorJogo([FromBody] Guid id)
        {
            try
            {
                return new JogoTenisRegraModelResponse { Sucesso = false, MensagemRetorno = "Não implementado!" };

            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

    }
}
