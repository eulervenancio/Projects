﻿using System;

namespace TennisProgram
{
    class Program
    {

      
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
