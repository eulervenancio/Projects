﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using TennisProgram.Domain.Interfaces.Resositories;
using TennisProgram.Domain.Interfaces.UnitOfWork;
using TennisProgram.Domain.Interfaces.Services;
using TennisProgram.Infra.Data.Repositories;
using TennisProgram.Infra.Data.Uow;
using TennisProgram.Service.Service;
using TennisProgram.Infra.Data.Interfaces;
using TennisProgram.Infra.Data.Context;
using MongoDB.Driver;

namespace TennisProgram.Infra.IoC
{
    public class InjetorDependencias
    {
        private readonly IServiceCollection _services;
        private readonly IConfiguration _configuration;

        public InjetorDependencias(IServiceCollection services, IConfiguration configuration)
        {
            this._services = services;
            this._configuration = configuration;
        }

        public void ConfigurarDependencias()
        {
            _services.AddSingleton<IConfiguration>(x => _configuration);

            ConfigurarService();
            ConfigurarRepositories();
            
            _services.AddHttpClient();

            _services.AddScoped(c => c.GetService<IMongoClient>().StartSession());
        }

        private void ConfigurarRepositories()
        {
            _services.AddScoped<IUnitOfWork, UnitOfWork>();
            _services.AddScoped<IMongoContext, MongoContext>();
            _services.AddScoped<IJogoTenisRepository, JogoTenisRepository>();
            _services.AddScoped<IJogadorRepository, JogadorRepository>();
        }

        private void ConfigurarService()
        {
            _services.AddScoped<IJogadorService, JogadorService>();
            _services.AddScoped<IJogoTenisService, JogoTenisService>();
            _services.AddScoped<IJogoTenisRegraService, JogoTenisRegraService>();

        }
    }
}
