﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TennisProgram.Test;
using System;
using System.Collections.Generic;
using System.Text;

namespace TennisProgram.Test.Tests
{
    [TestClass()]
    public class TestsTests
    {
        [TestMethod()]
        public void SetupTest()
        {
            Assert.Fail();
        }
    }
}